# -*- coding: utf-8 -*-
"""
TV ao vivo: canais abertos e públicos (lista mantida pelo projeto iptv-org).

- Cada fonte pode ser testada; o resultado fica salvo em live_status.json.
- Canais cujas fontes falharam todas no último teste podem ser escondidos.
- Ao tocar, as fontes são testadas na hora e a primeira que responder é usada.
"""

import os
import re
import time
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed

from . import kids
from .common import PROFILE, UA, _, http_text, log, read_json_file, write_json_file

IPTV_URLS = [
    "https://iptv-org.github.io/iptv/countries/br.m3u",
    "https://raw.githubusercontent.com/iptv-org/iptv/master/streams/br.m3u",
]
BLOCKED = ("xxx", "adult")
STATUS_FILE = os.path.join(PROFILE, "live_status.json")
STATUS_MAX_AGE = 24 * 3600


def group_label(g):
    return {
        "News": _("News"), "Religious": _("Religious"), "General": _("Variety"),
        "Entertainment": _("Entertainment"), "Music": _("Music"), "Kids": _("Kids"),
        "Animation": _("Animation"), "Sports": _("Sports"), "Movies": _("Movies"),
        "Series": _("Series"), "Education": _("Education"), "Culture": _("Culture"),
        "Documentary": _("Documentary"), "Legislative": _("Legislative"),
        "Business": _("Business"), "Lifestyle": _("Lifestyle"), "Comedy": _("Comedy"),
        "Classic": _("Classic"), "Outdoor": _("Outdoor"), "Travel": _("Travel"),
        "Cooking": _("Cooking"), "Auto": _("Auto"), "Family": _("Family"),
        "Science": _("Science"), "Shop": _("Shopping"), "Weather": _("Weather"),
        "Undefined": _("Other"),
    }.get(g, g)


# --------------------------------------------------------------------------
# Lista de canais
# --------------------------------------------------------------------------
def load_channels():
    text = None
    for url in IPTV_URLS:
        try:
            text = http_text(url, ttl=6 * 3600)
            if "#EXTINF" in text:
                break
        except Exception as exc:
            log("Lista de canais indisponível em {}: {}".format(url, exc))
    if not text:
        return []
    channels, seen, cur = [], {}, None
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("#EXTINF"):
            attrs = dict(re.findall(r'([\w-]+)="([^"]*)"', line))
            name = line.rsplit(",", 1)[-1].strip()
            cur = {
                "name": name,
                "id": attrs.get("tvg-id") or name,
                "logo": attrs.get("tvg-logo", ""),
                "groups": [g.strip() for g in (attrs.get("group-title") or "Undefined").split(";")
                           if g.strip()],
                "headers": {},
            }
        elif line.startswith("#EXTVLCOPT") and cur is not None:
            m = re.match(r"#EXTVLCOPT:http-(user-agent|referrer)=(.+)", line, re.I)
            if m:
                key = "User-Agent" if m.group(1).lower() == "user-agent" else "Referer"
                cur["headers"][key] = m.group(2).strip()
        elif line and not line.startswith("#") and cur is not None:
            cur["url"] = line
            low = (cur["name"] + " " + " ".join(cur["groups"])).lower()
            if not any(b in low for b in BLOCKED):
                key = cur["id"].lower()
                if key in seen:
                    seen[key]["alts"].append(cur)
                else:
                    cur["alts"] = []
                    seen[key] = cur
                    channels.append(cur)
            cur = None
    channels.sort(key=lambda c: c["name"].lower())
    if kids.is_on():
        channels = [c for c in channels if any(g in kids.KIDS_LIVE_GROUPS for g in c["groups"])]
    return channels


def clean_name(name):
    return re.sub(r"\s*\[(Not 24/7|Geo-blocked)\]", "", name, flags=re.I).strip()


def sources(chan):
    return [chan] + chan.get("alts", [])


def find(ident):
    return next((c for c in load_channels() if c["id"] == ident), None)


# --------------------------------------------------------------------------
# Teste das fontes
# --------------------------------------------------------------------------
def check_stream(src, timeout=6):
    headers = {"User-Agent": UA}
    headers.update(src.get("headers") or {})
    try:
        req = urllib.request.Request(src["url"], headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if resp.status >= 400:
                return False
            data = resp.read(4096)
            if ".m3u8" in src["url"].lower() or b"#EXT" in data[:16]:
                return b"#EXTM3U" in data
            return len(data) > 0
    except Exception:
        return False


def load_status():
    return read_json_file(STATUS_FILE, {})


def save_status(status):
    try:
        write_json_file(STATUS_FILE, status)
    except OSError:
        pass


def source_state(status, src):
    entry = status.get(src["url"])
    if not entry or time.time() - entry[1] > STATUS_MAX_AGE:
        return None
    return bool(entry[0])


def channel_state(status, chan):
    states = [source_state(status, s) for s in sources(chan)]
    if any(s is True for s in states):
        return True
    if states and all(s is False for s in states):
        return False
    return None


def check_all(channels=None, progress=None, workers=24):
    """Testa todas as fontes. progress(feitos, total) -> False cancela."""
    channels = channels if channels is not None else load_channels()
    srcs = [s for c in channels for s in sources(c)]
    status = load_status()
    total, done, ok = len(srcs), 0, 0
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(check_stream, s): s for s in srcs}
        for fut in as_completed(futures):
            src = futures[fut]
            result = fut.result()
            status[src["url"]] = [result, int(time.time())]
            done += 1
            ok += 1 if result else 0
            if progress and progress(done, total) is False:
                for f in futures:
                    f.cancel()
                break
    status["_last_check"] = [True, int(time.time())]
    save_status(status)
    return ok, done


def last_check_age():
    entry = load_status().get("_last_check")
    return time.time() - entry[1] if entry else None


def pick_working_source(chan):
    """Testa as fontes do canal na hora (as que funcionaram antes primeiro)."""
    status = load_status()
    order = {True: 0, None: 1, False: 2}
    candidates = sorted(sources(chan), key=lambda s: order[source_state(status, s)])
    chosen = None
    for src in candidates:
        good = check_stream(src, timeout=5)
        status[src["url"]] = [good, int(time.time())]
        if good:
            chosen = src
            break
    save_status(status)
    return chosen


def play_url(src):
    headers = {"User-Agent": UA}
    headers.update(src.get("headers") or {})
    return src["url"] + "|" + urllib.parse.urlencode(headers)
