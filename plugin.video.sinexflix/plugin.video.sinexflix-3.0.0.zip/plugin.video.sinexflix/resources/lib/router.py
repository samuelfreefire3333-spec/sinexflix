# -*- coding: utf-8 -*-
"""Recebe a URL do Kodi e chama a tela certa."""

import sys
import traceback
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin

from . import kids, library, storage, tmdb, views
from .common import ADDON, BASE_URL, HANDLE, _, clear_cache, log, notify, refresh
from .local import browse as local_browse

# Telas que não podem ser abertas no modo infantil sem a senha
LOCKED_IN_KIDS = {"tools", "settings", "kids_pin", "clear_cache", "library_sync",
                  "library_help", "tmdb_test", "tmdb_help", "live_check"}
# Modos que resolvem um vídeo (precisam de setResolvedUrl em caso de erro)
PLAY_MODES = {"ia_play", "live_play"}


def _int(p, key, default=0):
    try:
        return int(p.get(key) or default)
    except ValueError:
        return default


def dispatch(mode, p):
    if mode in LOCKED_IN_KIDS and not kids.unlock():
        if mode == "tools":
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    routes = {
        "main": views.main_menu,
        "movies_menu": lambda: views.type_menu("movie"),
        "series_menu": lambda: views.type_menu("series"),
        "genres": lambda: views.list_genres(p.get("type", "movie")),
        "years": lambda: views.list_years(p.get("type", "movie")),
        "catalog": lambda: views.list_catalog(p.get("type", "movie"), p.get("cid", "top"),
                                              p.get("genre") or None, _int(p, "skip")),
        "title": lambda: views.title_page(p.get("type", "movie"), p["imdb"]),
        "providers": lambda: views.providers_page(p.get("type", "movie"), p["imdb"], p.get("name", "")),
        "provider_open": lambda: tmdb.open_provider(p.get("pname", ""), p.get("title", ""),
                                                    p.get("cat", ""), p.get("link", "")),
        "season": lambda: views.list_season(p["imdb"], _int(p, "season", 1)),
        "trailer": lambda: views.play_trailer(p.get("type", "movie"), p["imdb"]),
        "ia_menu": views.ia_menu,
        "ia_list": lambda: views.ia_list(p.get("q"), p.get("coll"), p.get("year"), p.get("sort"),
                                         _int(p, "page", 1)),
        "ia_play": lambda: views.ia_play(p["id"]),
        "random": views.ia_random,
        "watched": views.watched_list,
        "upcoming": views.upcoming_list,
        "live_menu": views.live_menu,
        "live": lambda: views.live_list(p.get("group")),
        "live_play": lambda: views.live_play(p["id"]),
        "live_check": views.live_check,
        "local": lambda: local_browse(p.get("path")),
        "my_list": views.my_list,
        "list_toggle": lambda: storage.toggle(p["kind"], p["id"], p.get("name", ""),
                                              p.get("poster", ""), p.get("fanart", ""),
                                              p.get("year", "")),
        "search_menu": lambda: views.search_menu(p.get("scope")),
        "search_new": lambda: views.search_new(p.get("scope")),
        "search_results": lambda: views.search_results(p["q"], p.get("scope")),
        "history_remove": lambda: storage.history_remove(p["q"]),
        "clear_history": storage.clear_history,
        "clear_watched": storage.clear_watched,
        "tools": views.tools_menu,
        "settings": ADDON.openSettings,
        "clear_cache": clear_cache,
        "tmdb_help": tmdb.show_setup_help,
        "tmdb_test": views.tmdb_test,
        "library_sync": views.library_sync,
        "library_help": lambda: library.first_time_help(force=True),
        "install_yt": lambda: xbmc.executebuiltin("InstallAddon(plugin.video.youtube)"),
        "kids_pin": kids.change_pin,
        "noop": lambda: None,
    }

    if mode == "kids_on":
        if kids.enable():
            xbmc.executebuiltin("Container.Update({},replace)".format(BASE_URL))
        return
    if mode == "kids_off":
        if kids.disable():
            refresh()
        return
    routes.get(mode, views.main_menu)()


def run():
    args = sys.argv[2][1:] if len(sys.argv) > 2 else ""
    p = dict(urllib.parse.parse_qsl(args))
    mode = p.get("mode", "main")
    try:
        dispatch(mode, p)
    except Exception as exc:
        log("ERRO em '{}': {}\n{}".format(mode, exc, traceback.format_exc()), xbmc.LOGERROR)
        notify(_("Error: {}").format(exc), xbmcgui.NOTIFICATION_ERROR, 6000)
        if mode in PLAY_MODES:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        elif HANDLE >= 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
