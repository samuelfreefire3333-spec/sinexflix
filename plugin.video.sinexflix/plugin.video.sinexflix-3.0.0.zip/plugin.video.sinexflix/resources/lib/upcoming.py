# -*- coding: utf-8 -*-
"""Episódios recentes e próximos das séries da Minha Lista (usado no menu e no serviço)."""

import time

from . import cinemeta, storage
from .common import log


def collect(days_back=7, days_ahead=30):
    now = time.time()
    start = time.strftime("%Y-%m-%d", time.localtime(now - days_back * 86400))
    end = time.strftime("%Y-%m-%d", time.localtime(now + days_ahead * 86400))
    eps = []
    for show in [i for i in storage.visible_list() if i.get("kind") == "series"]:
        try:
            meta = cinemeta.get_meta("series", show["id"])
        except Exception as exc:
            log("Falha ao ler {}: {}".format(show.get("name"), exc))
            continue
        for v in meta.get("videos") or []:
            rel = cinemeta.release_date(v)
            if rel and start <= rel <= end and v.get("season"):
                eps.append((rel, show, meta, v))
    eps.sort(key=lambda e: e[0])
    return eps
